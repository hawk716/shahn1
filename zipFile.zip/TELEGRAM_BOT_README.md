# بوت التيليجرام لإدارة السحب - دليل شامل

## المميزات الرئيسية

### 1. نظام الصلاحيات والأمان
- **مشرف رئيسي**: المستخدم برقم 8083596989 هو صاحب الصلاحيات الكاملة
- **إضافة مشرفين**: استخدام الأمر `/admin {user_id}` (من المشرف الرئيسي فقط)
- **حماية كاملة**: البوت لا يستجيب إلا للمشرفين المصرح لهم

### 2. معالجة طلبات السحب
عند استقبال طلب سحب من الموقع:
```
👤 المستخدم: [الاسم]
💰 الرصيد الكلي: [المبلغ]
📥 مسحوبات سابقة: [الرقم]
📅 تاريخ التسجيل: [التاريخ]
📊 السجل: [العدد] ناجحة | [العدد] فاشلة
```

### 3. واجهة الأزرار التفاعلية

**المرحلة الأولى** (عند وصول الطلب):
- "قبول 🟢" - قبول الطلب والانتقال للمرحلة الثانية
- "مراسلة 📧" - عرض بريد العميل

**المرحلة الثانية** (بعد الضغط على قبول):
- "موافقة ✅" (أخضر) - الموافقة على السحب
- "رفض ❌" (أحمر) - رفض السحب

عند الاختيار، يتم تحديث الرسالة فوراً لعرض الحالة النهائية والوقت.

### 4. إدارة المعاملات
- زر ثابت "المعاملات 📋" في القائمة السفلية
- عرض آخر 10 معاملات مع حالتها
- إمكانية عرض تفاصيل كل معاملة
- زر "تحديث 🔄" لتنشيط القائمة

## البنية الهندسية

```
bot/
├── __init__.py          # Package init
├── database.py          # إدارة قاعدة البيانات SQLite
├── main.py             # البوت الرئيسي مع المعالجات
├── requirements.txt     # المكتبات المطلوبة
├── .env.example        # مثال على متغيرات البيئة
└── bot_data.db         # قاعدة البيانات (ينشأ تلقائياً)

app/api/
└── telegram/
    └── webhook/
        └── route.ts    # API Endpoint للربط مع الموقع
```

## المتطلبات

- Python 3.10+
- pip
- Node.js (للموقع)

## خطوات التثبيت

### 1. تثبيت البوت

```bash
# نسخ ملف البيئة
cp bot/.env.example bot/.env

# تثبيت المكتبات
cd bot
pip install -r requirements.txt
```

### 2. الحصول على بيانات التيليجرام

**الحصول على BOT_TOKEN:**
1. تواصل مع [@BotFather](https://t.me/BotFather)
2. أرسل `/newbot`
3. اتبع التعليمات واحصل على التوكن
4. ضع التوكن في `bot/.env` تحت `TELEGRAM_BOT_TOKEN`

**الحصول على ADMIN_CHAT_ID:**
1. أضف البوت لمجموعة أو استخدمه بشكل خاص
2. أرسل رسالة للبوت
3. افتح: `https://api.telegram.org/bot{TOKEN}/getUpdates`
4. ابحث عن `chat.id` وضعه في `bot/.env` تحت `TELEGRAM_ADMIN_CHAT_ID`

### 3. تشغيل البوت

```bash
python -m main
```

## قاعدة البيانات (SQLite)

### جدول المشرفين (admins)
```sql
user_id     INTEGER  (المفتاح الأساسي)
username    TEXT
role        TEXT     ('master' أو 'assistant')
added_at    TIMESTAMP
```

### جدول طلبات السحب (withdrawal_requests)
```sql
request_id                 TEXT (معرف فريد)
user_id                    INTEGER
username                   TEXT
app_name                   TEXT
currency                   TEXT
amount                     REAL
account_number             TEXT
total_balance              REAL
previous_withdrawals       TEXT
account_creation_date      TEXT
success_count              INTEGER
failed_count               INTEGER
status                     TEXT ('pending', 'approved', 'rejected')
approved_by                INTEGER
approved_at                TIMESTAMP
message_id                 INTEGER
created_at                 TIMESTAMP
```

## API Endpoint

### POST `/api/telegram/webhook`

يتم استدعاؤه تلقائياً من مسار السحب في الموقع.

**البيانات المرسلة:**
```json
{
  "user_id": 123,
  "username": "أحمد",
  "app_name": "محفظة جيب",
  "currency": "ريال يمني (قديم)",
  "amount": 1000,
  "account_number": "123456789",
  "total_balance": 5000,
  "previous_withdrawals": 2000,
  "account_creation_date": "2024-01-01",
  "success_count": 5,
  "failed_count": 1
}
```

## الأوامر

- `/start` - بدء البوت (للمشرفين فقط)
- `/admin {user_id}` - إضافة مشرف جديد (المشرف الرئيسي فقط)

## المزايا التقنية

- **aiogram 3.3**: أحدث إصدار من مكتبة Telegram
- **SQLite**: قاعدة بيانات محلية آمنة
- **FSM (Finite State Machine)**: للتحكم بالحوارات المعقدة
- **Callback Queries**: للأزرار التفاعلية
- **Inline Keyboards**: واجهة مستخدم متقدمة

## استكشاف الأخطاء

### البوت لا يرد على الأوامر
- تأكد من أن `TELEGRAM_BOT_TOKEN` صحيح
- تأكد من أن user_id الخاص بك موجود في قاعدة البيانات

### لا تظهر الرسائل في التيليجرام
- تأكد من أن `TELEGRAM_ADMIN_CHAT_ID` صحيح
- تأكد من أن البوت لديه صلاحيات الإرسال

### مشاكل الاتصال مع الموقع
- تأكد من أن `/api/telegram/webhook` متاح
- تحقق من متغيرات البيئة في الموقع

## الأمان

- يتم حفظ جميع البيانات محلياً في SQLite
- لا يتم مشاركة بيانات حساسة مع جهات خارجية
- التحقق من الصلاحيات في كل عملية
- استخدام callback_data آمن بدلاً من البيانات المباشرة

## الدعم والصيانة

- يتم تسجيل جميع العمليات في السجلات
- قاعدة البيانات قابلة للنسخ الاحتياطي
- يمكن إضافة مشرفين جدد في أي وقت
