import { UserPortal } from "@/components/user-portal"

export default function PortalPage() {
  return <UserPortal />
}
