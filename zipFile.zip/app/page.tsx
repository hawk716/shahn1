import { UserPortal } from "@/components/user-portal"

export default function Home() {
  return <UserPortal />
}
